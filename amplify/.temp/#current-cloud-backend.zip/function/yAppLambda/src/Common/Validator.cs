namespace yAppLambda.Common;

public class Validator
{
    
}